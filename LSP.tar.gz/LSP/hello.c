  #include<unistd.h>

    main()
	{
 
        	int   rt;  
  	write(1,"HELLO WORLD\n",12);
  
	}
