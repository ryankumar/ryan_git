#include<stdio.h>
#include<ctype.h>
int main()
{
  char c;
  c=getchar();
  putchar(c);
}
